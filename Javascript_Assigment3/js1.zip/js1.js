var ullist = document.createElement('li');
ullist.innerText = "lokesh";
console.log(ullist);



